import { Page, expect }  from "@playwright/test";
import pipelinePage from "../page-elements/pipeline-page-element.json" with { type: "json" };
import leadsPage from "../page-elements/leads-page-element.json" with { type: "json" };
import { WebCommons } from "../../commons/ui/web-commons";
import leadsData from "../../testdata/ui/leads-page-data.json" with { type: "json" };
import config from "../../config/config.json" with { type: "json" };

export class PipelinePageSteps {
  page: Page;
  web: WebCommons;

  // Constructor to initialize the page and web commons
  constructor(page: Page) {
    this.page = page;
    this.web = new WebCommons(this.page);
  }

  async verifyPipelinePageIsDisplayed(): Promise<void> {
    await this.web.waitForLoadDOMContent()    
    await this.web.isElementVisible(pipelinePage.pipelineMenuLink, 'getByTestId')
    await this.web.isElementVisible(pipelinePage.pipelineTitle, 'getByTestId')
    await this.web.isElementVisible(pipelinePage.pipelineDescr, 'xpath')
    await this.web.isElementVisible(pipelinePage.pipelineQualifiedHeader, 'xpath')
    await this.web.isElementVisible(pipelinePage.pipelineProposalHeader, 'xpath')
    await this.web.isElementVisible(pipelinePage.pipelineNegotiationHeader, 'xpath')
    await this.web.isElementVisible(pipelinePage.pipelineWonHeader, 'xpath')
    await this.web.isElementVisible(pipelinePage.pipelineLostHeader, 'xpath')
    console.log('Pipeline page is displayed successfully')
  }

   async verifyDragDrop(company: string): Promise<void>{

    const src = await (await this.web.element(pipelinePage.pipelineLeadCompany, 'xpath')).filter({ hasText: `${company}`}) //page.locator('p').filter({ hasText: `${company}` })
    const trg = await this.web.element(pipelinePage.pipelineProposalStage, 'getByTestId') //page.getByRole('region', { name: `${section}` });
    
    await src.dragTo(trg)
    // Verify lead is now inside Proposal section
    // await this.web.
    await expect(trg.locator('p').filter({ hasText: `${company}` })).toBeVisible();    
    await this.web.waitForTimeout(3000)
  }

/*  async verifyNewLeadFormIsDisplayed(jobTitle: string, empStatus: string): Promise<void>{ 
    await this.web.isElementVisible(leadsPage.newLeadModalTitle, 'xpath')
    await this.web.isElementVisible(leadsPage.newLeadModalCloseButton, 'getByTestId')
    await this.web.isElementVisible(leadsPage.contactNameTextBox, 'getByTestId')
    await this.web.isElementVisible(leadsPage.companyTextBox, 'getByTestId')
    await this.web.isElementVisible(leadsPage.emailTextBox, 'getByTestId')
    await this.web.isElementVisible(leadsPage.phoneTextBox, 'getByTestId')
    await this.web.isElementVisible(leadsPage.leadSourceDropdown, 'xpath')
    await this.web.isElementVisible(leadsPage.estValueTextBox, 'getByTestId')
    await this.web.isElementVisible(leadsPage.saveLeadButton, 'getByTestId')
    console.log('New Lead form is displayed successfully')
  }

  async verifyCreateNewLead(contactName: string, company: string, email: string, phone: string, source: string, estValue: string): Promise<void>{
    await this.web.enterText(leadsPage.contactNameTextBox, 'getByTestId', contactName)
    await this.web.verifyTextFilled(leadsPage.contactNameTextBox, 'getByTestId', contactName)
    await this.web.enterText(leadsPage.companyTextBox, 'getByTestId', company)
    await this.web.verifyTextFilled(leadsPage.companyTextBox, 'getByTestId', company)
    await this.web.enterText(leadsPage.emailTextBox, 'getByTestId', email)
    await this.web.verifyTextFilled(leadsPage.emailTextBox, 'getByTestId', email)
    await this.web.enterText(leadsPage.phoneTextBox, 'getByTestId', phone)
    await this.web.verifyTextFilled(leadsPage.phoneTextBox, 'getByTestId', phone)
    await this.web.selectOption(leadsPage.leadSourceDropdown, 'xpath', source)
    // await this.web.verifyDropdownValueSelected(leadsPage.leadSourceDropdown, 'xpath', source)
    await this.web.enterText(leadsPage.estValueTextBox, 'getByTestId', estValue)
    await this.web.verifyTextFilled(leadsPage.estValueTextBox, 'getByTestId', estValue)
    await this.web.click(leadsPage.saveLeadButton, 'getByTestId')
    console.log('New Lead details are provided successfully')
  }

  async verifySearchLead(contactName: string): Promise<void>{
    await this.web.enterText(leadsPage.leadSearchTextBox, 'getByTestId', contactName)
    console.log('Search contact name is entered successfully')
  }


  async verifyLeadIsDisplayed(contactName: string, company: string, email: string, source: string): Promise<void>{
    await this.web.isElementVisible(leadsPage.leadContactLabel, 'xpath')
    await this.web.isElementVisible(leadsPage.leadCompanyLabel, 'xpath')
    await this.web.isElementVisible(leadsPage.leadEmailLabel, 'xpath')
    await this.web.isElementVisible(leadsPage.leadSourceLabel, 'xpath')
    console.log('New Lead is displayed successfully')
    // await this.web.waitForTimeout(9000) // Wait for 2 seconds to ensure the lead is displayed
  }

  async verifyClickOnLead(): Promise<void>{
    await this.web.click(leadsPage.leadContactLabel, 'xpath')
    console.log('Searched Lead is clicked successfully')
  }

  async verifyConvertToLeadPageIsDisplayed(): Promise<void>{
    await this.web.isElementVisible(leadsPage.backToLeadsLink, 'getByTestId')
    await this.web.isElementVisible(leadsPage.convertToLeadTitle, 'getByTestId')
    await this.web.isElementVisible(leadsPage.convertToLeadDescription, 'xpath')
    await this.web.isElementVisible(leadsPage.convertToLeadStatus, 'xpath')
    await this.web.isElementVisible(leadsPage.convertToLeadNoteButton, 'getByTestId')
    await this.web.isElementVisible(leadsPage.convertToLeadNoteTextarea, 'getByPlaceholder')
    await this.web.isElementVisible(leadsPage.convertToLeadLogCallButton, 'getByTestId')
    await this.web.isElementVisible(leadsPage.convertToLeadEmailButton, 'getByTestId')
    await this.web.isElementVisible(leadsPage.convertToLeadSaveNoteButton, 'getByTestId')
    await this.web.isElementVisible(leadsPage.convertToLeadActivityTimelineLabel, 'getByTestId')
    await this.web.isElementVisible(leadsPage.convertToLeadOwnerLable, 'xpath')
    await this.web.isElementVisible(leadsPage.convertToLeadOwnerValueLable, 'xpath')
    await this.web.isElementVisible(leadsPage.convertToLeadSourceLable, 'xpath')
    await this.web.isElementVisible(leadsPage.convertToLeadSourceValueLable, 'xpath')
    await this.web.isElementVisible(leadsPage.convertToLeadEstLable, 'xpath')
    await this.web.isElementVisible(leadsPage.convertToLeadEstValueLable, 'xpath')
    await this.web.isElementVisible(leadsPage.convertToLeadStatusDropdown, 'getByTestId')
    await this.web.isElementVisible(leadsPage.convertToLeadButton, 'getByTestId')
    console.log('Convert to Lead page is displayed successfully')
  }

  async verifySaveNotes(note: string, callSummary: string, emailSummary: string): Promise<void>{
    await this.web.click(leadsPage.convertToLeadNoteButton, 'getByTestId')
    await this.web.enterText(leadsPage.convertToLeadNoteTextarea, 'getByPlaceholder', note)
    await this.web.verifyTextFilled(leadsPage.convertToLeadNoteTextarea, 'getByPlaceholder', note)
    await this.web.click(leadsPage.convertToLeadSaveNoteButton, 'getByTestId')
    await this.web.verifyDisplayedText(leadsPage.convertToLeadSavedNoteLog, 'xpath', note)
    await this.web.click(leadsPage.convertToLeadLogCallButton, 'getByTestId')
    await this.web.enterText(leadsPage.convertToLeadLogCallTextarea, 'getByPlaceholder', callSummary)
    await this.web.verifyTextFilled(leadsPage.convertToLeadLogCallTextarea, 'getByPlaceholder', callSummary)
    await this.web.click(leadsPage.convertToLeadSaveNoteButton, 'getByTestId')
    await this.web.verifyDisplayedText(leadsPage.convertToLeadSavedCallLog, 'xpath', callSummary)
    await this.web.click(leadsPage.convertToLeadEmailButton, 'getByTestId')
    await this.web.enterText(leadsPage.convertToLeadLogEmailTextarea, 'getByPlaceholder', emailSummary)
    await this.web.verifyTextFilled(leadsPage.convertToLeadLogEmailTextarea, 'getByPlaceholder', emailSummary)
    await this.web.click(leadsPage.convertToLeadSaveNoteButton, 'getByTestId')
    await this.web.verifyDisplayedText(leadsPage.convertToLeadSavedEmailLog, 'xpath', emailSummary)
    console.log('Note is added and saved successfully')
  }

  async verifyConvertToDeal(status: string): Promise<void> {
    await this.web.selectOption(leadsPage.convertToLeadStatusDropdown, 'getByTestId', status)
    await this.web.click(leadsPage.convertToLeadButton, 'getByTestId')    
    console.log('Status Provided and CLicked on convert to deal successfully')
  }

  async verifyConfirmConvertToDealFormIsDisplayed(): Promise<void>{
    await this.web.isElementVisible(leadsPage.confirmCreateDealFormTitle, 'xpath')
    await this.web.isElementVisible(leadsPage.confirmCreateDealFormClose, 'getByTestId')
    await this.web.isElementVisible(leadsPage.confirmCreateDealValueLabel, 'xpath')
    await this.web.isElementVisible(leadsPage.confirmCreateDealValueTextbox, 'getByTestId')
    await this.web.isElementVisible(leadsPage.confirmCreateDealLeadEstLabel, 'xpath')
    await this.web.isElementVisible(leadsPage.confirmCreateDealExpCloseLabel, 'xpath')
    await this.web.isElementVisible(leadsPage.confirmCreateDealCloseDropdown, 'getByTestId')
    await this.web.isElementVisible(leadsPage.confirmCreateDealButton, 'getByTestId')
    console.log('Confirm Convert To Deal Form is Displayed Successfully')
  }

  async verifyConfirmConvertToDeal(dealValue: string, expClose: string): Promise<void>{
    await this.web.enterText(leadsPage.confirmCreateDealValueTextbox, 'getByTestId', dealValue)
    await this.web.verifyTextFilled(leadsPage.confirmCreateDealValueTextbox, 'getByTestId', dealValue)
    await this.web.selectOption(leadsPage.confirmCreateDealCloseDropdown, 'getByTestId', expClose)
    await this.web.click(leadsPage.confirmCreateDealButton, 'getByTestId')
    await this.web.isElementVisible(leadsPage.convertToLeadBanner, 'getByTestId')
    console.log('Deal Created Successfully')
  }
 */
}
import { test, TestInfo } from "@playwright/test";
import { APICommons } from "../../commons/api/api-commons.ts";
import authData from "../../testdata/api/auth-data.json";

test.describe("Auth Test", () => {
  let apiCommons: APICommons;
  let token: any;
  let testInfo: TestInfo;

  // Initialize the api instance before each test to share base url, headers etc
  test.beforeEach(async () => {
    apiCommons = new APICommons();
    await apiCommons.InitializeRequestContext();
  });

  test("Wrong password", async () => {
    const userData = authData.user
    const data = authData.wrongPassword;
    token = await apiCommons.generateToken(userData.user1.userName)
    await apiCommons.getResponse(
      data.requestType,
      data.endpoint,
      undefined,
      token,
    );
    await apiCommons.validateStatusCode(data.expCode);
    await apiCommons.validateStatusMessage(data.expStatusMessage);
    await apiCommons.validateResponseBody(data.codeKey, data.codeValue);
    await apiCommons.validateResponseBody(data.messageKey, data.messageValue);
  });

    test.skip("Who Am I", async () => {
    const userData = authData.user.user1;
    const data = authData.whoAmI;
    token = await apiCommons.generateToken(userData.userName);
    await apiCommons.getResponse(
      data.requestType,
      data.endpoint,
      undefined,
      token,
    );
    await apiCommons.validateStatusCode(data.expCode);
    await apiCommons.validateStatusMessage(data.expStatusMessage);
    await apiCommons.validateResponseBody(data.userIdKey, userData.userIdValue);
    await apiCommons.validateResponseBody(
      data.userNameKey,
      userData.userNameValue,
    );
    await apiCommons.validateResponseBody(data.nameKey, userData.nameValue);
    await apiCommons.validateResponseBody(
      data.userEmailKey,
      userData.userEmailValue,
    );
    await apiCommons.validateResponseBody(data.userRoleKey, data.userRoleValue);
  });
});
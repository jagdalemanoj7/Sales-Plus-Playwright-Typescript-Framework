import { test, TestInfo } from '@playwright/test'
import { LoginPageSteps } from '../../page-objects/page-steps/login-page-steps.ts'
import { DashboardPageSteps } from '../../page-objects/page-steps/dashboard-page-steps.ts'
import { LeadsPageSteps } from '../../page-objects/page-steps/leads-page-steps.ts'
import { PipelinePageSteps } from '../../page-objects/page-steps/pipeline-page-steps.ts'
import leadsData from '../../testdata/ui/leads-page-data.json' with {type : 'json'}
import config from '../../config/config.json' with {type : 'json'}

let loginPage : LoginPageSteps
let dashboardPage: DashboardPageSteps
let leadsPage: LeadsPageSteps
let pipelinePage: PipelinePageSteps
let testInfo : TestInfo
let testData : any

test.describe('Leads Page Feature Test', () => {

    test.beforeEach( async ({ page }) => {
        loginPage = new LoginPageSteps(page)
        dashboardPage = new DashboardPageSteps(page)
        leadsPage = new LeadsPageSteps(page)
        pipelinePage = new PipelinePageSteps(page)
        await loginPage.launchApplication()
        await loginPage.verifyLoginPageIsDisplayed()
        await loginPage.verifyProvideLoginCredentials(config.app['username'], config.app['password'])
        await loginPage.verifyClickOnLoginBtn()
    })

    test('Verify Assigned Owner Of Bulk Lead Filtered With Status', async ({}, testInfo: TestInfo) => {
        testData = leadsData[testInfo.title as keyof typeof leadsData]

        await test.step('Verify Dashboard Page Is Displayed', async () => {
            await dashboardPage.verifyDashboardPageIsDisplayed()
        })

        await test.step('Verify Leads Menu Link Is Clicked', async () => {
            await leadsPage.verifyClickOnLeadMenuLink()
        })

        await test.step('Verify Leads Page Is Displayed', async () => {
            await leadsPage.verifyLeadsPageIsDisplayed()
        })

        await test.step('Verify Status Option Are Selected And Applied To All Lead', async () => {
            await leadsPage.verifySelectStatusOption(testData['statusOptions'])
        })

        await test.step('Verify All Filtered Leads Checkbox Is Selected', async() =>{
            await leadsPage.verifySelectAllLeadsCheckboxIsSelected()
        })

        await test.step('Verify Owner Options Are Selected From Dropdown', async () => {
            await leadsPage.verifyOwnerIsSelectedFromDropdown(testData['owner'])
        })
        
        await test.step('Verify Apply Button Is Clicked', async() => {
            await leadsPage.verifyOwnerFilterApplyButtonClick()
        })
        
        await test.step('Verify Owner Options Are Applied To All Filtered Leads And Displayed', async() => {
            await leadsPage.verifySelectedOwnerAppliedToLead(testData['owner'])
        })        

    })
})
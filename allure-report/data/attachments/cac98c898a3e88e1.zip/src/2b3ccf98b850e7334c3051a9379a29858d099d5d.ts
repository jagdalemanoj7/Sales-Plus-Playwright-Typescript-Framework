import { Page } from "@playwright/test";
import loginPage from "../page-elements/login-page-element.json" with { type: "json" };
import { WebCommons } from "../../commons/ui/web-commons";
import data from "../../testdata/ui/login-page-data.json" with { type: "json" };
import config from "../../config/config.json" with { type: "json" };

export class LoginPageSteps {
  page: Page;
  web: WebCommons;

  // Constructor to initialize the page and web commons
  constructor(page: Page) {
    this.page = page;
    this.web = new WebCommons(this.page);
  }

  // Method to launch the application
  async launchApplication(): Promise<void> {
    await this.web.launchApplication(config.app.url, config.app.title);
    console.log("Application launched successfully");
  }

  async verifyLoginPageIsDisplayed(): Promise<void> {
    await this.web.isElementVisible(loginPage.salesPulseLogo, "getByTestId");
    await this.web.isElementVisible(loginPage.signInHeader, "xpath");
    await this.web.isElementVisible(loginPage.crmPracticeAppHeader1, "xpath");
    await this.web.isElementVisible(loginPage.crmPracticeAppHeader2, "xpath");
    await this.web.isElementVisible(loginPage.crmPracticeAppHeader3, "xpath");
    await this.web.isElementVisible(loginPage.crmDescription1, 'xpath')
    await this.web.isElementVisible(loginPage.crmDescription2, 'xpath')    
    console.log("Login page is displayed successfully");
  }

  async verifyProvideLoginCredentials(username: string, password: string): Promise<void>{
    await this.web.enterText(loginPage.workEmailText, 'getByTestId', username)
    await this.web.enterText(loginPage.passwordText, 'getByTestId', password)
  }

  async verifyClickOnRememberMeCheckbox(): Promise<void> {
    await this.web.click(loginPage.rememberMeCheckbox, 'getByTestId')
  }

  async verifyClickOnKeepMeSignedInLabel(): Promise<void> {
    await this.web.click(loginPage.keepMeSignedInLabel, 'xpath')
  }

  async verifyLoginErrorMessageIsDisplayed(): Promise<void> {
    await this.web.isElementVisible(loginPage.loginErrorMessage, 'getByTestId')
  }

  async verifyClickOnLoginBtn(): Promise<void> {
    await this.web.click(loginPage.loginBtn, 'getByTestId')
  }
}

import { test, TestInfo } from '@playwright/test'
import { APICommons } from '../../commons/api/api-commons.ts'
import authData from '../../testdata/api/auth-data.json'

test.describe('Auth Test', async() => {
    let apiCommons : APICommons
    let token : any
    let testInfo : TestInfo

    // Initialize the api instance before each test to share base url, headers etc
    test.beforeEach(async() => {
        apiCommons = new APICommons()
        await apiCommons.InitializeRequestContext()
    })

    test.skip('Admin Login', async() => {
        const data = authData.loginAsAdmin
        await apiCommons.getResponse(data.requestType, data.endpoint, data.payload)
        await apiCommons.validateStatusCode(data.expCode)
        await apiCommons.validateStatusMessage(data.expStatusMessage)
        await apiCommons.validateResponseBody(data.tokenTypeKey, data.tokenTypeValue)
        await apiCommons.validateResponseBody(data.expiresInKey, data.expiresInValue)
        await apiCommons.validateResponseBody(data.userIdKey, data.userIdValue)
        await apiCommons.validateResponseBody(data.userNameKey, data.userNameValue)
        await apiCommons.validateResponseBody(data.nameKey, data.nameValue)
        await apiCommons.validateResponseBody(data.userEmailKey, data.userEmailValue)
        await apiCommons.validateResponseBody(data.userRoleKey, data.userRoleValue)
    })

    test.skip('User 1 Login', async() => {
        const data = authData.loginAsUserRavi
        await apiCommons.getResponse(data.requestType, data.endpoint, data.payload)
        await apiCommons.validateStatusCode(data.expCode)
        await apiCommons.validateStatusMessage(data.expStatusMessage)
        await apiCommons.validateResponseBody(data.tokenTypeKey, data.tokenTypeValue)
        await apiCommons.validateResponseBody(data.expiresInKey, data.expiresInValue)
        await apiCommons.validateResponseBody(data.userIdKey, data.userIdValue)
        await apiCommons.validateResponseBody(data.userNameKey, data.userNameValue)
        await apiCommons.validateResponseBody(data.nameKey, data.nameValue)
        await apiCommons.validateResponseBody(data.userEmailKey, data.userEmailValue)
        await apiCommons.validateResponseBody(data.userRoleKey, data.userRoleValue)
    })

    test.skip('User 2 Login', async() => {
        const data = authData.loginAsUserMeera
        await apiCommons.getResponse(data.requestType, data.endpoint, data.payload)
        await apiCommons.validateStatusCode(data.expCode)
        await apiCommons.validateStatusMessage(data.expStatusMessage)
        await apiCommons.validateResponseBody(data.tokenTypeKey, data.tokenTypeValue)
        await apiCommons.validateResponseBody(data.expiresInKey, data.expiresInValue)
        await apiCommons.validateResponseBody(data.userIdKey, data.userIdValue)
        await apiCommons.validateResponseBody(data.userNameKey, data.userNameValue)
        await apiCommons.validateResponseBody(data.nameKey, data.nameValue)
        await apiCommons.validateResponseBody(data.userEmailKey, data.userEmailValue)
        await apiCommons.validateResponseBody(data.userRoleKey, data.userRoleValue)
    })

    test('Who Am I', async() => {
        const user = authData.user
        const data = authData.whoAmI
        token = await apiCommons.generateToken(user.user1)
        await apiCommons.getResponse(data.requestType, data.endpoint, token)
        await apiCommons.validateStatusCode(data.expCode)
        await apiCommons.validateStatusMessage(data.expStatusMessage)
        await apiCommons.validateResponseBody(data.userIdKey, data.user1.userIdValue)
        await apiCommons.validateResponseBody(data.userNameKey, data.user1.userNameValue)
        await apiCommons.validateResponseBody(data.nameKey, data.user1.nameValue)
        await apiCommons.validateResponseBody(data.userEmailKey, data.user1.userEmailValue)
        await apiCommons.validateResponseBody(data.userRoleKey, data.userRoleValue)
    })
})
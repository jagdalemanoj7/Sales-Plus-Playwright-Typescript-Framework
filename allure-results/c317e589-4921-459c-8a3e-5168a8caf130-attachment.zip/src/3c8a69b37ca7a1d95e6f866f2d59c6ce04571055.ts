import { test, TestInfo } from "@playwright/test";
import { APICommons } from "../../commons/api/api-commons.ts";
import authData from '../../testdata/api/auth-data.json'
import prodData from "../../testdata/api/product-data.json";
import orderData from '../../testdata/api/order-data.json'

test.describe("Order Test", () => {
  let apiCommons: APICommons;
  let token: any;
  let testInfo: TestInfo;

  // Initialize the api instance before each test to share base url, headers etc
  test.beforeEach(async () => {
    apiCommons = new APICommons();
    await apiCommons.InitializeRequestContext();
  });

  test("[B5] Another customer's order → 403", async () => {
    const userData = authData.loginAsUserRavi;
    token = await apiCommons.generateToken(userData.userName);
    // await apiCommons.getResponse(adminData.requestType, adminData.endpoint, adminData.payload);
    const data = orderData.anotherCustomersOrder;
    const payload = `${data.endpoint}/${data.productId}`
    await apiCommons.getResponse(
      data.requestType,
      data.endpoint,
      undefined,
      token
    );
    await apiCommons.validateStatusCode(data.expCode);
    await apiCommons.validateStatusMessage(data.expStatusMessage);
    await apiCommons.validateResponseBody(data.codeKey, data.codeValue);
    await apiCommons.validateResponseBody(data.messageKey, data.messageValue);
  });

});

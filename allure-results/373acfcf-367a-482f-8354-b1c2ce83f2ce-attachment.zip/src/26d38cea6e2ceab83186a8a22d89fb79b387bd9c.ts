import { Page, Locator, expect, FrameLocator } from "@playwright/test";

export class WebCommons {
  page: Page;

  // Constructor to initilize the page
  constructor(page: Page) {
    this.page = page;
  }

  // Common method to generate WebElement from the locator
  async element(
    locator: string,
    locatorType: string,
    frameLocator?: string,
    role?: any,
  ): Promise<Locator> {
    switch (locatorType) {
      case "xpath":
        return this.page.locator(locator);
        break;
      case "getByText":
        return this.page.getByText(locator);
        break;
      case "getByLabel":
        return this.page.getByLabel(locator);
        break;
      case "getByPlaceholder":
        return this.page.getByPlaceholder(locator);
        break;
      case "getByAltText":
        return this.page.getByAltText(locator);
        break;
      case "getByTitle":
        return this.page.getByTitle(locator);
        break;
      case "getByTestId":
        return this.page.getByTestId(locator);
        break;
      case "getByRole":
        return this.page.getByRole(role, { name: locator });
        break;
      case "frame":
        return this.page.frameLocator(frameLocator).locator(locator);
        break;
      default:
        throw new Error(`Invalid locator Type: ${locatorType}`);
    }
  }

  // Common method to launch the application
  async launchApplication(url: string, title: string): Promise<void> {
    await this.page.goto(url);
    await this.page.waitForURL(url);
    await this.page.setViewportSize({ width: 1520, height: 810 });
    await expect(this.page).toHaveTitle(title);
  }

  // common method to locate iframe
  /* async frameLocator(frameLocator: string, locator: string): Promise<Locator>{
      return this.page.frameLocator(frameLocator).locator(locator)
  } */

  // Scroll to specified element
  async scrollToElement(
    locator: string,
    locatorType: string,
    frameLocator?: string,
    role?: any,
    index?:number | undefined,
  ): Promise<void> {
    const element = await this.element(
      locator,
      locatorType,
      frameLocator,
      role,
    );
    await element.scrollIntoViewIfNeeded({ timeout: 60000 });
  }

  // Click to element
  async click(
    locator: string,
    locatorType: string,
    frameLocator?: string,
    framelocatorType?: string,
    role?: any,
  ): Promise<void> {
    const element = await this.element(
      locator,
      locatorType,
      frameLocator,
      framelocatorType,
      role,
    );
    await this.scrollToElement(
      locator,
      locatorType,
      frameLocator,
      framelocatorType,
      role,
    );
    await element.click();
  }

  // Double Click
  async doubleClick(
    locator: string,
    locatorType: string,
    frameLocator?: string,
    role?: any,
  ): Promise<void> {
    const element = await this.element(
      locator,
      locatorType,
      frameLocator,
      role,
    );
    await this.scrollToElement(locator, locatorType, frameLocator, role);
    await element.dblclick();
  }

  // Right click
  async rightClick(
    locator: string,
    locatorType: string,
    frameLocator?: string,
    role?: any,
  ): Promise<void> {
    const element = await this.element(
      locator,
      locatorType,
      frameLocator,
      role,
    );
    await this.scrollToElement(locator, locatorType, frameLocator, role);
    await element.click({ button: "right" });
  }

  // Hover on an element
  async hoverElement(
    locator: string,
    locatorType: string,
    frameLocator?: string,
    role?: any,
  ): Promise<void> {
    const element = await this.element(
      locator,
      locatorType,
      frameLocator,
      role,
    );
    await this.scrollToElement(locator, locatorType, frameLocator, role);
    await element.hover();
  }

  // Force Click to element
  async forceClick(
    locator: string,
    locatorType: string,
    frameLocator?: string,
    role?: any,
  ): Promise<void> {
    const element = await this.element(
      locator,
      locatorType,
      frameLocator,
      role,
    );
    await this.scrollToElement(locator, locatorType, frameLocator, role);
    await element.click({ force: true });
  }

  // Clear to element
  async clearText(
    locator: string,
    locatorType: string,
    frameLocator?: string,
    role?: any,
  ): Promise<void> {
    const element = await this.element(
      locator,
      locatorType,
      frameLocator,
      role,
    );
    await this.scrollToElement(locator, locatorType, frameLocator, role);
    await element.clear();
  }

  // Type text into the textbox element
  async enterText(
    locator: string,
    locatorType: string,
    text: string,
    frameLocator?: string,
    role?: any,
  ): Promise<void> {
    const element = await this.element(
      locator,
      locatorType,
      frameLocator,
      role,
    );
    await this.scrollToElement(locator, locatorType, frameLocator, role);
    await element.fill(text);
  }

  // get the text provided in the textbox
  async getText(
    locator: string,
    locatorType: string,
    frameLocator?: string,
    role?: any,
  ): Promise<string> {
    const element = await this.element(
      locator,
      locatorType,
      frameLocator,
      role,
    );
    await this.scrollToElement(locator, locatorType, frameLocator, role);
    return await element.inputValue();
  }

  // Press key on an element
  async pressKey(
    locator: string,
    locatorType: string,
    key: string,
    frameLocator?: string,
    role?: any,
  ): Promise<void> {
    const element = await this.element(
      locator,
      locatorType,
      frameLocator,
      role,
    );
    await this.scrollToElement(locator, locatorType, frameLocator, role);
    await element.press(key);
  }

  // Select option from dropdown
  async selectOption(
    locator: string,
    locatorType: string,
    option: string,
    frameLocator?: string,
    role?: any,
  ): Promise<void> {
    const element = await this.element(
      locator,
      locatorType,
      frameLocator,
      role,
    );
    await this.scrollToElement(locator, locatorType, frameLocator, role);
    await element.selectOption(option);
  }

  // get the text from element using textContent() method
  async getElementText(
    locator: string,
    locatorType: string,
    frameLocator?: string,
    role?: any,
  ): Promise<string | null> {
    const element = await this.element(
      locator,
      locatorType,
      frameLocator,
      role,
    );
    await this.scrollToElement(locator, locatorType, frameLocator, role);
    return await element.textContent();
  }

  // Compare text values
  async compareText(actual: string, expected: string): Promise<void> {
    if (!actual.match(expected)) {
      throw new Error(`Expected Value is ${expected} , But found ${actual}`);
    }
  }

  // get the text from element using innerText() method
  async getElementInnerText(
    locator: string,
    locatorType: string,
    index?: number,
    frameLocator?: string,
    role?: any,
  ): Promise<string | null> {
    const element = await this.element(
      locator,
      locatorType,
      frameLocator,
      role,
    );
    // await this.scrollToElement(locator, locatorType, frameLocator, role);
    return await element.nth(index).innerText();
  }

  // get the all text from elements using innerText() method
  async getAllElementInnerText(
    locator: string,
    locatorType: string,
    frameLocator?: string,
    role?: any,
  ): Promise<string[] | null> {
    const element = await this.element(
      locator,
      locatorType,
      frameLocator,
      role,
    );
    await this.scrollToElement(locator, locatorType, frameLocator, role);
    return await element.allInnerTexts();
  }

  async verifyTextFilled(
    locator: string,
    locatorType: string,
    expectedValue: string,
    frameLocator?: string,
    role?: any,
  ): Promise<void> {
    const element = await this.element(
      locator,
      locatorType,
      frameLocator,
      role,
    );
    await expect(element).toHaveValue(expectedValue);
  }

  async verifyDisplayedText(
    locator: string,
    locatorType: string,
    expectedText: string,
    index?: number | undefined,
    frameLocator?: string,
    role?: any,
    
  ): Promise<void> {
    const element = await this.element(
      locator,
      locatorType,
      frameLocator,
      role,
    );
    await expect(element.nth(index)).toHaveText(expectedText);
  }

  async verifyElementCount(
    locator: string,
    locatorType: string,
    count: number,
    frameLocator?: string,
    role?: any,
    
  ): Promise<void> {
    const element = await this.element(
      locator,
      locatorType,
      frameLocator,
      role,
    );    
    await expect(element).toHaveCount(count)
  }

  /*   async verifyDropdownValueSelected(locator: string, locatorType: string, expectedValue: string, frameLocator?: string, role?: any): Promise<void> {
    const element = await this.element(locator, locatorType, frameLocator, role);
    await expect(element).toHaveValue(expectedValue);
  } */

  // Get element attribute
  async getElementAttribute(
    locator: string,
    locatorType: string,
    attribute: string,
    frameLocator?: string,
    role?: any,
  ): Promise<string | null> {
    const element = await this.element(
      locator,
      locatorType,
      frameLocator,
      role,
    );
    await this.scrollToElement(locator, locatorType, frameLocator, role);
    return await element.getAttribute(attribute);
  }

  // Upload an element
  async uploadFile(
    locator: string,
    locatorType: string,
    filePath: string,
    frameLocator?: string,
    role?: any,
  ): Promise<void> {
    const element = await this.element(
      locator,
      locatorType,
      frameLocator,
      role,
    );
    await this.scrollToElement(locator, locatorType, frameLocator, role);
    await element.setInputFiles(filePath);
  }

  async scrollToFilteredElement(
    element: Locator
  ): Promise<void>{
    await element.scrollIntoViewIfNeeded({ timeout: 50000 })
  }

  // Filter rlement
  async filter(
    locator: string,
    locatorType: string,
    data: string,
    frameLocator?: string,
    role?: any,
  ): Promise<Locator> {
    const element = await this.element(
      locator,
      locatorType,
      frameLocator,
      role,
    );
    const filteredElement = await element.filter({ hasText: data });
    await this.scrollToFilteredElement(filteredElement)
    await expect(filteredElement).toBeVisible({ timeout: 50000 })
    return filteredElement;
  }

  // Filter rlement
  async locatorFilter(
    outerLocator: string,
    outerLocatorType: string,
    innerLocator: string,
    innerLocatorType: string,
    data: string,
    frameLocator?: string,
    role?: any,
  ): Promise<Locator> {
    const outerElement = await this.element(outerLocator, outerLocatorType, frameLocator, role,);
    const innerElement = await this.element(innerLocator, innerLocatorType, frameLocator, role,);
    // await this.scrollToFilteredElement(outerElement)
    // await this.scrollToFilteredElement(innerElement)

    const filteredElement = await outerElement.filter({ has: innerElement.filter( {hasText: data }) })
                            //    outerElement.filter({ has: page.locator('td', { hasText: company }) });
    // await this.scrollToFilteredElement(filteredElement)
    await expect(filteredElement).toBeVisible({ timeout: 50000 })
    return filteredElement;
  }

  // Drag and Drop Element
  async dragAndDrop(
    sourceElement: Locator,
    targetElement: Locator,
  ): Promise<void> {
    await sourceElement.dragTo(targetElement);
  }

  // Verify element having text value
  async verifyElementText(
    locator: string,
    locatorType: string,
    expectedText: string,
    frameLocator?: string,
    role?: any,
  ) {
    const element = await this.element(
      locator,
      locatorType,
      frameLocator,
      role,
    );
    await expect(element).toHaveText(expectedText);
  }
  
  // Check if an element is visible
  async isElementVisible(
    locator: string,
    locatorType: string,
    frameLocator?: string,
    role?: any,
    data?: string
  ): Promise<void> {
    const element = await this.element(
      locator,
      locatorType,
      frameLocator,
      role,
    );
    await this.scrollToElement(locator, locatorType, frameLocator, role);
    await expect(element).toBeVisible({ timeout: 50000 });    
  }

  // Check if an element is enabled
  async isElementEnabled(
    locator: string,
    locatorType: string,
    frameLocator?: string,
    role?: any,
  ): Promise<void> {
    const element = await this.element(
      locator,
      locatorType,
      frameLocator,
      role,
    );
    await this.scrollToElement(locator, locatorType, frameLocator, role);
    await expect(element).toBeEnabled();
  }

  // Check if an element is enabled
  async isElementEditable(
    locator: string,
    locatorType: string,
    frameLocator?: string,
    role?: any,
  ): Promise<void> {
    const element = await this.element(
      locator,
      locatorType,
      frameLocator,
      role,
    );
    await this.scrollToElement(locator, locatorType, frameLocator, role);
    await expect(element).toBeEditable();
  }

  // Check if an element is hidden
  async isElementHidden(
    locator: string,
    locatorType: string,
    frameLocator?: string,
    role?: any,
  ): Promise<void> {
    const element = await this.element(
      locator,
      locatorType,
      frameLocator,
      role,
    );
    await this.scrollToElement(locator, locatorType, frameLocator, role);
    await expect(element).toBeHidden();
  }

  // Check if an Checkbox/ Radio is not selected
  async isCheckboxNotChecked(
    locator: string,
    locatorType: string,
    frameLocator?: string,
    role?: any,): Promise<void> {
    const element = await this.element(
      locator,
      locatorType,
      frameLocator,
      role,
    );    
    await this.scrollToElement(locator, locatorType, frameLocator, role);
    await expect(element).not.toBeChecked()
  }

  // Check if an Checkbox/ Radio is selected
  async isCheckboxChecked(
    locator: string,
    locatorType: string,
    frameLocator?: string,
    role?: any,): Promise<void> {
    const element = await this.element(
      locator,
      locatorType,
      frameLocator,
      role,
    );    
    await this.scrollToElement(locator, locatorType, frameLocator, role);
    await expect(element).toBeChecked()
  }
  
  // Handle alert pop-up
  async handleAlert(
    action: "accept" | "dismiss",
    textToEnter?: string,
  ): Promise<void> {
    this.page.on("dialog", async (dialog) => {
      if (action === "accept") {
        await dialog.accept(textToEnter);
      } else {
        await dialog.dismiss();
      }
    });
  }

  // Take screenshot of the page
  async takeScreenshot(path: string): Promise<void> {
    await this.page.screenshot({ path });
  }

  // Get count
  async getCount(
    locator: string,
    locatorType: string,
    frameLocator?: string,
    role?: any,
  ): Promise<number>{
    const element = await this.element(locator, locatorType, frameLocator, role);
    // await this.scrollToElement(locator, locatorType, frameLocator, role);
    return await element.count()
  }

  // verify expected value contains actual value
  async verifyValueContains(actual: string, expected: string) {}

  // custum wait
  async waitForTimeout(timeout: number): Promise<void> {
    await this.page.waitForTimeout(timeout);
  }

  //  wait for page load
  async waitForLoadPage(): Promise<void> {
    await this.page.waitForLoadState("load");
  }

  //  wait for dom content load
  async waitForLoadDOMContent(): Promise<void> {
    await this.page.waitForLoadState("domcontentloaded");
  }
}

import { test, TestInfo } from "@playwright/test";
import { APICommons } from "../../commons/api/api-commons.ts";
import prodData from "../../testdata/api/product-data.json";

test.describe("Product Test", () => {
  let apiCommons: APICommons;
  let token: any;
  let testInfo: TestInfo;

  // Initialize the api instance before each test to share base url, headers etc
  test.beforeEach(async () => {
    apiCommons = new APICommons();
    await apiCommons.InitializeRequestContext();
  });

  test("Get product by id", async () => {
    const data = prodData.getProductDetailsById;
    const endpoint = `${data.endpoint}/${data.productId}`
    await apiCommons.getResponse(
      data.requestType,
      endpoint,
    );
    await apiCommons.validateStatusCode(data.expCode);
    await apiCommons.validateStatusMessage(data.expStatusMessage);
    await apiCommons.validateResponseBody(data.idKey, data.idValue);
    await apiCommons.validateResponseBody(data.nameKey, data.nameValue)
    await apiCommons.validateResponseBody(data.skuKey, data.skuValue)
    await apiCommons.validateResponseBody(data.categoryKey, data.categoryValue)
    await apiCommons.validateResponseBody(data.priceKey, data.priceValue)
    await apiCommons.validateResponseBody(data.stockKey, data.stockValue)
    await apiCommons.validateResponseBody(data.ratingKey, data.ratingValue)
    await apiCommons.validateResponseHeader(data.etagHeader, data.etagValue)
  });

});

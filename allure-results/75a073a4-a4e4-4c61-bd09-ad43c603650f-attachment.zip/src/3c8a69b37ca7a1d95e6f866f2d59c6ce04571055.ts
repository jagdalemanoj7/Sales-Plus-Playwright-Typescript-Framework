import { test, TestInfo } from "@playwright/test";
import { APICommons } from "../../commons/api/api-commons.ts";
import prodData from "../../testdata/api/product-data.json";

test.describe("Product Test", () => {
  let apiCommons: APICommons;
  let token: any;
  let testInfo: TestInfo;

  // Initialize the api instance before each test to share base url, headers etc
  test.beforeEach(async () => {
    apiCommons = new APICommons();
    await apiCommons.InitializeRequestContext();
  });

  test("Sort by price, highest first", async () => {
    const data = prodData.sortByPriceHighestFirst;
    await apiCommons.getResponse(
      data.requestType,
      data.endpoint,
      undefined,
      undefined,
      data.queryParams
    );
    await apiCommons.validateStatusCode(data.expCode);
    await apiCommons.validateStatusMessage(data.expStatusMessage);
    await apiCommons.validateResponseBody(data.totalKey, data.totalValue);
    await apiCommons.validateSortedPriceInDescendingOrder(data.dataKey, data.priceKey)
  });

});

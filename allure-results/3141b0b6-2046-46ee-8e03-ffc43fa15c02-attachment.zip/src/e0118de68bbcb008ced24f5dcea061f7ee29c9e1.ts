import { test, TestInfo } from '@playwright/test'
import { LoginPageSteps } from '../../page-objects/page-steps/login-page-steps.ts'
import { DashboardPageSteps } from '../../page-objects/page-steps/dashboard-page-steps.ts'
import { LeadsPageSteps } from '../../page-objects/page-steps/leads-page-steps.ts'
import leadsData from '../../testdata/ui/leads-page-data.json' with {type : 'json'}
import config from '../../config/config.json' with {type : 'json'}

let loginPage : LoginPageSteps
let dashboardPage: DashboardPageSteps
let leadsPage: LeadsPageSteps
let testInfo : TestInfo
let testData : any

test.describe('Leads Page Feature Test', ()=>{
    test.beforeEach( async ({ page }) =>{
        loginPage = new LoginPageSteps(page)
        dashboardPage = new DashboardPageSteps(page)
        leadsPage = new LeadsPageSteps(page)
        await loginPage.launchApplication()
        await loginPage.verifyLoginPageIsDisplayed()
        await loginPage.verifyProvideLoginCredentials(config.app['username'], config.app['password'])
        await loginPage.verifyClickOnLoginBtn()
    })

    test('Verify create new lead and convert it', async ({ }, testInfo: TestInfo)=> {

        testData = leadsData[testInfo.title as keyof typeof leadsData]
        
        await test.step('Verify leads page is displayed', async () => {
            await dashboardPage.verifyDashboardPageIsDisplayed()
        })

        await test.step('Click on Work My Leads button', async () => {
            await dashboardPage.clickOnWorkMyLeadsButton()
        })

        await test.step('Verify leads page is displayed', async () => {
            await leadsPage.verifyLeadsPageIsDisplayed()
        })

        await test.step('Click on New Lead button', async () => {
            await leadsPage.verifyClickOnNewLeadButton()
        })

        await test.step('Verify new lead form is displayed', async () => {
            await leadsPage.verifyNewLeadFormIsDisplayed(testData['jobTitle'], testData['empStatus'])
        })

        await test.step('Verify create new lead', async () => {
            await leadsPage.verifyCreateNewLead(testData['contactName'], testData['company'], testData['email'], testData['phone'], testData['source'], testData['estValue'])
        })

        await test.step('Verify lead is displayed', async () => {
            await leadsPage.verifySearchLead(testData['contactName'])
            await leadsPage.verifyLeadIsDisplayed(testData['contactName'], testData['company'], testData['email'], testData['source'])
        })
    })
})
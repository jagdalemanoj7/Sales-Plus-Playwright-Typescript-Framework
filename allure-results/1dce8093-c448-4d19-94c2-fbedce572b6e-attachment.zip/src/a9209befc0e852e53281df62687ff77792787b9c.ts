import { Page } from "@playwright/test";
import { DashboardPageLocators } from "../page-elements/dashboard-page-locators";
import { WebCommons } from "../../commons/ui/web-commons";
import data from "../../testdata/ui/login-page-data.json" with { type: "json" };
import config from "../../config/config.json" with { type: "json" };

export class DashboardPageSteps {
    page : Page
    web: WebCommons
    dashboardPageLocators : DashboardPageLocators

    constructor(page: Page){
        this.page = page,
        this.web = new WebCommons(this.page)
        this.dashboardPageLocators = new DashboardPageLocators(this.page)
    }

    async verifyDashboardPageIsDisplayed(): Promise<void>{
        await this.web.waitForLoadDOMContent()
        await this.web.isElementVisible(this.dashboardPageLocators.welcomeHeader,)
        // console.log('logo is displayed')
        await this.web.isElementVisible(this.dashboardPageLocators.userLabel,) 
        // console.log('welcome header is displayed')       
        await this.web.isElementVisible(this.dashboardPageLocators.dashboardMenuLink,)        
        // console.log('change pwd link is displayed')
        await this.web.isElementVisible(this.dashboardPageLocators.leadsMenuLink,)
        // console.log('logout link is displayed')
        await this.web.isElementVisible(this.dashboardPageLocators.pipelineMenuLink,)
        // console.log('emp info header is displayed')
        await this.web.isElementVisible(this.dashboardPageLocators.logoutButton,)
        console.log('Dashboard Page is displayed successfully')        
    }

    async clickOnLogoutBtn(): Promise<void>{
        await this.web.click(this.dashboardPageLocators.logoutButton,)
        console.log('logout Button is clicked')
    }

    async clickOnWorkMyLeadsButton(): Promise<void> {
        await this.web.click(this.dashboardPageLocators.workMyLeadsButton,)
        console.log('Leads button is clicked')
    }
 
    async verifyIsDisplayedClickOnPipelineButton(): Promise<void> {
        await this.web.isElementVisible(this.dashboardPageLocators.openPipelineButton)    
        // await this.web.click(dashboardPage.openPipelineButton, 'getByText')
        // console.log('Pipeline button is clicked')
    }

}
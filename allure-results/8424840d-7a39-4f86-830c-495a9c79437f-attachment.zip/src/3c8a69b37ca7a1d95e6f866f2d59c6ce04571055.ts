import { test, TestInfo } from "@playwright/test";
import { APICommons } from "../../commons/api/api-commons.ts";
import authData from '../../testdata/api/auth-data.json'
import prodData from "../../testdata/api/product-data.json";
import orderData from '../../testdata/api/order-data.json'

test.describe("Order Test", () => {
  let apiCommons: APICommons;
  let token: any;
  let testInfo: TestInfo;
  let orderId: number;

  // Initialize the api instance before each test to share base url, headers etc
  test.beforeEach(async () => {
    apiCommons = new APICommons();
    await apiCommons.InitializeRequestContext();
  });

  test("Place my order", async () => {
    const userData = authData.loginAsUserRavi;
    token = await apiCommons.generateToken(userData.userName);
    // await apiCommons.getResponse(adminData.requestType, adminData.endpoint, adminData.payload);
    const placeOrderData = orderData.placeAnOrder;
    await apiCommons.getResponse(
      placeOrderData.requestType,
      placeOrderData.endpoint,
      placeOrderData.payload,
      token
    );
    orderId = await apiCommons.getPropertyValue(placeOrderData.orderIdKey)
  });

  test("Cancel my order", async () => {
    const userData = authData.loginAsUserRavi;
    token = await apiCommons.generateToken(userData.userName);
    // await apiCommons.getResponse(adminData.requestType, adminData.endpoint, adminData.payload);
    const data = orderData.cancelMyOrder;
    const endpoint = `${data.endpoint1}/${orderId}/${data.endpoint2}`
    await apiCommons.getResponse(
      data.requestType,
      endpoint,
      undefined,
      token,
    );
    await apiCommons.validateStatusCode(data.expCode);
    await apiCommons.validateStatusMessage(data.expStatusMessage);
    await apiCommons.validateResponseBody(data.totalKey, data.totalValue);
    await apiCommons.validateResponseBody(data.statusKey, data.statusValue);
    await apiCommons.validateSpecificArrayKeyValue(data.itemsKey, 0, data.productIdKey, data.productIdValue)
    await apiCommons.validateSpecificArrayKeyValue(data.itemsKey, 0, data.nameKey, data.nameValue)
    await apiCommons.validateSpecificArrayKeyValue(data.itemsKey, 0, data.quantityKey, data.quantityValue)
    await apiCommons.validateSpecificArrayKeyValue(data.itemsKey, 0, data.unitPriceKey, data.unitPriceValue)
    await apiCommons.validateSpecificArrayKeyValue(data.itemsKey, 0, data.lineTotalKey, data.lineTotalValue)
  });

});

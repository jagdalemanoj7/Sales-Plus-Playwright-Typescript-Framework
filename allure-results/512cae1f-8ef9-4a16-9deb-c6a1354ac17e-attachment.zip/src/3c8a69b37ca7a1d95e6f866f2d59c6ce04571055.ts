import { test, TestInfo } from "@playwright/test";
import { APICommons } from "../../commons/api/api-commons.ts";
import prodData from "../../testdata/api/product-data.json";

test.describe("Product Test", () => {
  let apiCommons: APICommons;
  let token: any;
  let testInfo: TestInfo;

  // Initialize the api instance before each test to share base url, headers etc
  test.beforeEach(async () => {
    apiCommons = new APICommons();
    await apiCommons.InitializeRequestContext();
  });

  test("Search, by page", async () => {
    const data = prodData.searchByPage;
    await apiCommons.getResponse(
      data.requestType,
      data.endpoint,
      undefined,
      undefined,
      data.queryParams
    );
    await apiCommons.validateStatusCode(data.expCode);
    await apiCommons.validateStatusMessage(data.expStatusMessage);
    await apiCommons.validateSpecificKeyValue(data.dataKey, data.nameKey, data.nameValue)
  });
});

import { test, TestInfo } from "@playwright/test";
import { APICommons } from "../../commons/api/api-commons.ts";
import authData from '../../testdata/api/auth-data.json'
import prodData from "../../testdata/api/product-data.json";

test.describe("Product Test", () => {
  let apiCommons: APICommons;
  let token: any;
  let testInfo: TestInfo;

  // Initialize the api instance before each test to share base url, headers etc
  test.beforeEach(async () => {
    apiCommons = new APICommons();
    await apiCommons.InitializeRequestContext();
  });

  test("[B2] Zero price → 422", async () => {
    const adminData = authData.loginAsAdmin;
    token = await apiCommons.generateToken(adminData.userName);
    // await apiCommons.getResponse(adminData.requestType, adminData.endpoint, adminData.payload);
    const data = prodData.zeroPrice;
    await apiCommons.getResponse(
      data.requestType,
      data.endpoint,
      data.payload,
      token
    );
    await apiCommons.validateStatusCode(data.expCode);
    await apiCommons.validateStatusMessage(data.expStatusMessage);
    await apiCommons.validateResponseBody(data.codeKey, data.codeValue);
    await apiCommons.validateResponseBody(data.messageKey, data.messageValue);
    await apiCommons.validateResponseBody(data.fieldKey, data.fieldValue);
    await apiCommons.validateResponseBody(data.detailsMessageKey, data.detailsMessageValue);
  });

});

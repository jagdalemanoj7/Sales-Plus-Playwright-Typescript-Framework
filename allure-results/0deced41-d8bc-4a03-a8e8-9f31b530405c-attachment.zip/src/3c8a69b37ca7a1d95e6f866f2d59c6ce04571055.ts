import { test, TestInfo } from "@playwright/test";
import { APICommons } from "../../commons/api/api-commons.ts";
import authData from '../../testdata/api/auth-data.json'
import prodData from "../../testdata/api/product-data.json";

test.describe("Product Test", () => {
  let apiCommons: APICommons;
  let token: any;
  let testInfo: TestInfo;

  // Initialize the api instance before each test to share base url, headers etc
  test.beforeEach(async () => {
    apiCommons = new APICommons();
    await apiCommons.InitializeRequestContext();
  });

  test("[B1] Create product (admin) → 201", async () => {
    const adminData = authData.loginAsAdmin;
    token = await apiCommons.generateToken(adminData.userName);
    // await apiCommons.getResponse(adminData.requestType, adminData.endpoint, adminData.payload);
    const data = prodData.createProduct;
    await apiCommons.getResponse(
      data.requestType,
      data.endpoint,
      data.payload,
      token
    );
    await apiCommons.validateStatusCode(data.expCode);
    await apiCommons.validateStatusMessage(data.expStatusMessage);
    await apiCommons.validateResponseBody(data.idKey, data.idValue);
    await apiCommons.validateResponseBody(data.nameKey, data.nameValue)
    await apiCommons.validateResponseBody(data.skuKey, data.skuValue)
    await apiCommons.validateResponseBody(data.categoryKey, data.categoryValue)
    await apiCommons.validateResponseBody(data.priceKey, data.priceValue)
    await apiCommons.validateResponseBody(data.stockKey, data.stockValue)
    await apiCommons.validateResponseBody(data.ratingKey, data.ratingValue)
    await apiCommons.validateResponseHeader(data.etagHeader, data.etagValue)
  });

});

import { test, TestInfo } from "@playwright/test";
import { APICommons } from "../../commons/api/api-commons.ts";
import authData from '../../testdata/api/auth-data.json'
import prodData from "../../testdata/api/product-data.json";
import orderData from '../../testdata/api/order-data.json'

test.describe("Order Test", () => {
  let apiCommons: APICommons;
  let token: any;
  let testInfo: TestInfo;
  let orderId: number;

  // Initialize the api instance before each test to share base url, headers etc
  test.beforeEach(async () => {
    apiCommons = new APICommons();
    await apiCommons.InitializeRequestContext();
  });

  test("Out of stock → 409", async () => {
    const userData = authData.loginAsUserRavi;
    token = await apiCommons.generateToken(userData.userName);
    // await apiCommons.getResponse(adminData.requestType, adminData.endpoint, adminData.payload);
    const data = orderData.outOfStock;
    await apiCommons.getResponse(
      data.requestType,
      data.endpoint,
      data.payload,
      token
    );
    await apiCommons.validateStatusCode(data.expCode);
    await apiCommons.validateStatusMessage(data.expStatusMessage);
    await apiCommons.validateResponseBody(data.codeKey, data.codeValue);
    await apiCommons.validateResponseBody(data.messageKey, data.messageValue);
    await apiCommons.validateSpecificArrayKeyValue(data.detailsKey, 0, data.fieldKey, data.fieldValue);
    await apiCommons.validateSpecificArrayKeyValue(data.detailsKey, 0, data.detailsMessageKey, data.detailsMessageValue);
  });
  
});

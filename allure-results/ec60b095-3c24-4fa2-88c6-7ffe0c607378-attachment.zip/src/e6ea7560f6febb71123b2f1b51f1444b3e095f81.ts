import { Page } from "@playwright/test";
import dashboardPage from "../page-elements/dashboard-page-element.json" with { type: "json" };
import leadsPage from "../page-elements/leads-page-element.json" with { type: "json" };
import { WebCommons } from "../../commons/ui/web-commons";
import leadsData from "../../testdata/ui/leads-page-data.json" with { type: "json" };
import config from "../../config/config.json" with { type: "json" };

export class LeadsPageSteps {
  page: Page;
  web: WebCommons;

  // Constructor to initialize the page and web commons
  constructor(page: Page) {
    this.page = page;
    this.web = new WebCommons(this.page);
  }

  async verifyLeadsPageIsDisplayed(): Promise<void> {
    await this.web.waitForLoadDOMContent()    
    await this.web.isElementVisible(leadsPage.leadsMenuLink, 'getByTestId')
    await this.web.isElementVisible(leadsPage.leadsTitle, 'getByText')
    await this.web.isElementVisible(leadsPage.leadCountLabel, 'getByTestId')
    await this.web.isElementVisible(leadsPage.newLeadButton, 'getByTestId')
    console.log('Leads page is displayed successfully')
  }

  async verifyClickOnNewLeadButton(): Promise<void>{
    await this.web.click(leadsPage.newLeadButton, 'getByTestId')    
    console.log('clicked on New Lead button')
  }

  async verifyNewLeadFormIsDisplayed(jobTitle: string, empStatus: string): Promise<void>{ 
    await this.web.isElementVisible(leadsPage.newLeadModalTitle, 'getByText')
    await this.web.isElementVisible(leadsPage.newLeadModalCloseButton, 'getByTestId')
    await this.web.isElementVisible(leadsPage.contactNameTextBox, 'getByTestId')
    await this.web.isElementVisible(leadsPage.companyTextBox, 'getByTestId')
    await this.web.isElementVisible(leadsPage.emailTextBox, 'getByTestId')
    await this.web.isElementVisible(leadsPage.phoneTextBox, 'getByTestId')
    await this.web.isElementVisible(leadsPage.leadSourceDropdown, 'getByTestId')
    await this.web.isElementVisible(leadsPage.estValueTextBox, 'getByTestId')
    await this.web.isElementVisible(leadsPage.saveLeadButton, 'getByTestId')
    console.log('New Lead form is displayed successfully')
  }

  async verifyCreateNewLead(contactName: string, company: string, email: string, phone: string, source: string, estValue: string): Promise<void>{
    await this.web.enterText(leadsPage.contactNameTextBox, 'getByTestId', contactName)
    await this.web.enterText(leadsPage.companyTextBox, 'getByTestId', company)
    await this.web.enterText(leadsPage.emailTextBox, 'getByTestId', email)
    await this.web.enterText(leadsPage.phoneTextBox, 'getByTestId', phone)
    await this.web.selectOption(leadsPage.estValueTextBox, 'getByTestId', estValue)
    await this.web.selectOption(leadsPage.leadSourceDropdown, 'getByTestId', source)
    await this.web.click(leadsPage.saveLeadButton, 'getByTestId')
    console.log('New Lead details are provided successfully')
  }
}
import { Page } from "@playwright/test";
import dashboardPage from "../page-elements/dashboard-page-element.json" with { type: "json" };
import { WebCommons } from "../../commons/ui/web-commons";
import data from "../../testdata/ui/login-page-data.json" with { type: "json" };
import config from "../../config/config.json" with { type: "json" };

export class DashboardPageSteps {
    page : Page
    web: WebCommons

    constructor(page: Page){
        this.page = page,
        this.web = new WebCommons(this.page)
    }

    async verifyDashboardPageIsDisplayed(): Promise<void>{
        await this.web.waitForLoadDOMContent()
        await this.web.isElementVisible(dashboardPage.welcomeHeader, 'xpath')
        // console.log('logo is displayed')
        await this.web.isElementVisible(dashboardPage.userLabel, 'getByTestId') 
        // console.log('welcome header is displayed')       
        await this.web.isElementVisible(dashboardPage.dashboardMenuLink, 'getByTestId')        
        // console.log('change pwd link is displayed')
        await this.web.isElementVisible(dashboardPage.leadsMenuLink, 'getByTestId')
        // console.log('logout link is displayed')
        await this.web.isElementVisible(dashboardPage.pipelineMenuLink, 'getByTestId')
        // console.log('emp info header is displayed')
        await this.web.isElementVisible(dashboardPage.logoutButton, 'getByTestId')
        console.log('Dashboard Page is displayed successfully')
        await this.web.waitForTimeout(6000)
    }

    async clickOnLogoutBtn(): Promise<void>{
        await this.web.click(dashboardPage.logoutButton, 'getByTestId')
        console.log('logout Button is clicked')
    }

    async clickOnWorkMyLeadsButton(): Promise<void> {
        await this.web.click(dashboardPage.workMyLeadsButton, 'getByTestId')
        console.log('Leads button is clicked')
    }
 
    async verifyIsDisplayedClickOnPipelineButton(): Promise<void> {
        await this.web.isElementVisible(dashboardPage.openPipelineButton, 'getByText')    
        // await this.web.click(dashboardPage.openPipelineButton, 'getByText')
        // console.log('Pipeline button is clicked')
    }

}